you can include these in your mod.csv --

stringtable,csvname


if you dont know what to do with that info, you probably wont understand what these files are for.

By AintNoMeInTeam (xfire:aintnomeinteam)
attachmentTable.csv and didyouknow.csv fixed by BraX (xfire:maciusiak)


List of files:
	* attachmentTable.csv
	* classTable.csv
	* didyouknow.csv
	* mapsTable.csv
	* offline_classtable.csv
	* rankIconTable.csv
	* rankTable.csv
	* statsTable.csv