you can include these in your mod.csv --

stringtable,csvname


if you dont know what to do with that info, you probably wont understand what these files are for.

By AintNoMeInTeam